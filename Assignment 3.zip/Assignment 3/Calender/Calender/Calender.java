package com.cdac.util;

import com.cdac.util.MyDate;

public class Calender {

	
	
	public static void main(String[] args){
	
		MyDate date = new MyDate(4,6,2002);
		
		System.out.println(date);
		
	}

}
